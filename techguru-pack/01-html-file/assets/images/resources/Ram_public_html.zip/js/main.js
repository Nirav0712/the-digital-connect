/**
 * ParkN Solutions - Global Interactions
 */

document.addEventListener('DOMContentLoaded', () => {
    initMobileNav();
    initScrollReveal();
    initFAQAccordions();
    initCategoryFilters();
    initContactFormValidation();
    initHeroSlider();
});

/**
 * Mobile Navigation Menu
 */
function initMobileNav() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            navToggle.classList.toggle('open');
            navMenu.classList.toggle('active');
        });

        // Close menu when clicking a link
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('open');
                navMenu.classList.remove('active');
            });
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (navMenu.classList.contains('active') && 
                !navMenu.contains(e.target) && 
                !navToggle.contains(e.target)) {
                navToggle.classList.remove('open');
                navMenu.classList.remove('active');
            }
        });
    }
}

/**
 * Scroll Reveal Animations (Intersection Observer)
 */
function initScrollReveal() {
    const revealElements = document.querySelectorAll('.reveal');
    
    if ('IntersectionObserver' in window && revealElements.length > 0) {
        const revealObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                    observer.unobserve(entry.target); // Animation runs once
                }
            });
        }, {
            threshold: 0.15,
            rootMargin: '0px 0px -50px 0px'
        });

        revealElements.forEach(element => {
            revealObserver.observe(element);
        });
    } else {
        // Fallback for older browsers
        revealElements.forEach(element => {
            element.classList.add('active');
        });
    }
}

/**
 * FAQ Accordion Toggles
 */
function initFAQAccordions() {
    const accordionHeaders = document.querySelectorAll('.accordion-header');

    accordionHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const currentItem = header.parentElement;
            const content = currentItem.querySelector('.accordion-content');
            const isOpen = currentItem.classList.contains('active');

            // Close all other accordion items
            document.querySelectorAll('.accordion-item').forEach(item => {
                if (item !== currentItem) {
                    item.classList.remove('active');
                    item.querySelector('.accordion-content').style.maxHeight = null;
                }
            });

            // Toggle current item
            if (isOpen) {
                currentItem.classList.remove('active');
                content.style.maxHeight = null;
            } else {
                currentItem.classList.add('active');
                content.style.maxHeight = content.scrollHeight + 'px';
            }
        });
    });
}

/**
 * Category Filtering for Property and Blog Pages
 */
function initCategoryFilters() {
    const filterTabs = document.querySelectorAll('.filter-tab');
    const filterItems = document.querySelectorAll('.filter-item');

    if (filterTabs.length > 0 && filterItems.length > 0) {
        filterTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove active class from all tabs
                filterTabs.forEach(t => t.classList.remove('active'));
                
                // Add active class to clicked tab
                tab.classList.add('active');

                const filterValue = tab.getAttribute('data-filter');

                filterItems.forEach(item => {
                    const itemCategory = item.getAttribute('data-category');
                    
                    if (filterValue === 'all' || itemCategory === filterValue) {
                        item.classList.remove('hidden');
                    } else {
                        item.classList.add('hidden');
                    }
                });
            });
        });
    }
}

/**
 * Contact Form Client-Side Validation
 */
function initContactFormValidation() {
    const contactForm = document.getElementById('contactForm');
    const successOverlay = document.getElementById('successOverlay');
    const closeSuccessBtn = document.getElementById('closeSuccessBtn');

    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            let hasError = false;
            const nameInput = document.getElementById('formName');
            const emailInput = document.getElementById('formEmail');
            const phoneInput = document.getElementById('formPhone');
            const serviceInput = document.getElementById('formService');
            const msgInput = document.getElementById('formMessage');

            // Clean previous errors
            clearErrors();

            // Validate Name
            if (!nameInput.value.trim()) {
                showError(nameInput, 'Full Name is required');
                hasError = true;
            }

            // Validate Email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailInput.value.trim()) {
                showError(emailInput, 'Email Address is required');
                hasError = true;
            } else if (!emailRegex.test(emailInput.value.trim())) {
                showError(emailInput, 'Please enter a valid email address');
                hasError = true;
            }

            // Validate Phone
            const phoneRegex = /^[0-9\-\+\s\(\)]{10,15}$/;
            if (!phoneInput.value.trim()) {
                showError(phoneInput, 'Phone Number is required');
                hasError = true;
            } else if (!phoneRegex.test(phoneInput.value.replace(/[^0-9]/g, ''))) {
                showError(phoneInput, 'Please enter a valid 10-digit phone number');
                hasError = true;
            }

            // Validate Service Select
            if (serviceInput && !serviceInput.value) {
                showError(serviceInput, 'Please select a service option');
                hasError = true;
            }

            // Validate Message
            if (!msgInput.value.trim()) {
                showError(msgInput, 'Message is required');
                hasError = true;
            }

            // If no errors, show custom modal and reset form
            if (!hasError) {
                const userName = nameInput.value.trim();
                const selectedService = serviceInput ? serviceInput.options[serviceInput.selectedIndex].text : 'our services';
                
                const successTitle = document.getElementById('successTitle');
                const successMsg = document.getElementById('successMsg');
                
                if (successTitle && successMsg) {
                    successTitle.textContent = `Thank you, ${userName}!`;
                    successMsg.textContent = `Your request regarding "${selectedService}" has been submitted successfully. A ParkN solutions advisor will contact you within 24 hours.`;
                }

                if (successOverlay) {
                    successOverlay.classList.add('active');
                }

                contactForm.reset();
            }
        });
    }

    if (closeSuccessBtn && successOverlay) {
        closeSuccessBtn.addEventListener('click', () => {
            successOverlay.classList.remove('active');
        });

        // Close on clicking overlay bg
        successOverlay.addEventListener('click', (e) => {
            if (e.target === successOverlay) {
                successOverlay.classList.remove('active');
            }
        });
    }

    function showError(inputElement, message) {
        inputElement.classList.add('error');
        const parent = inputElement.parentElement;
        const errorDiv = document.createElement('div');
        errorDiv.className = 'form-error-msg';
        errorDiv.textContent = message;
        parent.appendChild(errorDiv);
    }

    function clearErrors() {
        const errorMsgs = document.querySelectorAll('.form-error-msg');
        errorMsgs.forEach(msg => msg.remove());

        const errorInputs = document.querySelectorAll('.form-input.error');
        errorInputs.forEach(input => input.classList.remove('error'));
    }
}

/**
 * Auto-sliding background hero slideshow for PARKN GREEN
 */
function initHeroSlider() {
    const hero = document.getElementById('homeHero');
    if (!hero) return;

    const slides = hero.querySelectorAll('.hero-slide');
    const dots = hero.querySelectorAll('.slider-dot');
    const prevBtn = document.getElementById('heroPrevBtn');
    const nextBtn = document.getElementById('heroNextBtn');
    
    if (slides.length === 0) return;

    let currentSlide = 0;
    let slideInterval;
    const intervalTime = 4000; // 4 seconds

    function showSlide(index) {
        // Remove active class from all slides and dots
        slides.forEach(slide => slide.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));

        // Calculate next index (infinitely loop forward and backward)
        currentSlide = (index + slides.length) % slides.length;
        slides[currentSlide].classList.add('active');
        if (dots[currentSlide]) {
            dots[currentSlide].classList.add('active');
        }
    }

    function nextSlide() {
        showSlide(currentSlide + 1);
    }

    function prevSlide() {
        showSlide(currentSlide - 1);
    }

    function startTimer() {
        clearInterval(slideInterval);
        slideInterval = setInterval(nextSlide, intervalTime);
    }

    function stopTimer() {
        clearInterval(slideInterval);
    }

    // Controls Action Listeners
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            nextSlide();
            startTimer(); // Reset auto-slide timer on click
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            prevSlide();
            startTimer(); // Reset auto-slide timer on click
        });
    }

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            showSlide(index);
            startTimer(); // Reset auto-slide timer on click
        });
    });

    // Pause Auto-sliding on Hover
    hero.addEventListener('mouseenter', stopTimer);
    hero.addEventListener('mouseleave', startTimer);

    // Start Auto-sliding Timer
    startTimer();
}
